import React, { useState, useEffect } from 'react';
import { Modal, Button } from 'antd';
import 'antd/dist/antd.css';
import './index.css';
import { Layout, Input, Card } from 'antd';
import Icon, { RadiusUprightOutlined } from '@ant-design/icons';
import serverProxy from "../../../../cvat-core/src/server-proxy";
import {useSelector } from 'react-redux'



const { Header, Footer, Sider, Content } = Layout;
const { Search } = Input;

// loading on search

const Signs: React.FC = () => {
    const [visible, setVisible] = useState(false);
    const [signs, setSigns] = useState([])
    const [asigns, setaSigns] = useState([])


    const currentJob = useSelector(state => state)
    // console.log(currentJob.annotation.job.requestedId)
    // console.log(JSON.stringify(currentJob))

    useEffect(() => {
        serverProxy.jobs.getcatalog(currentJob.annotation.job.requestedId).then((res) => {
            console.log(res);
            setSigns(res)
        });

    }, [])

    const SignsNode = (pid,fname) => {
        console.log(pid);
        // fetch(`http://localhost:8000/api/?pid=${pid}`)
        //     .then(res => res.json())
        //     .then(resp => setaSigns(resp))
        serverProxy.jobs.getPopulate(pid,fname).then((res) => {
            console.log(res);
            setaSigns(res)
        });


    }


    const RenderNode = (data) => {
        return data.data.map((item, index) => {
            return (
                <div key={index}>
                    <Button type="primary" shape="round" key={index} onClick={() => SignsNode(item.projectid,item.folder_name)} style={{ marginBottom: "3px" }}>{item.folder_name}</Button> <br />
                </div>
            )
        })
    }


    const SignRenderNode = (data) => {
        return data.data.map(obj =>
            Object.entries(obj).map(([key, value]) => (
                // <div key={key}>{value.imagepath} {value.signname} {value.projectid},,{value.signname} </div>
                <div key={key} >
                    <img src={value.imagepath} onClick={() =>alert("Image")} className="signs"/>
                </div>
            )))
    }

    return (
        <>
            <RadiusUprightOutlined onClick={() => setVisible(true)} />
            <Modal
                title="Signs"
                centered
                visible={visible}
                onOk={() => setVisible(false)}
                onCancel={() => setVisible(false)}
                width={1000}
            >
                <>
                    <Layout>
                        <Sider>
                            <Card>
                                <Search placeholder="input search loading default" style={{ marginBottom: "20px" }}></Search>
                                <br />
                                <div className="render"><RenderNode data={signs} /></div>

                            </Card>
                        </Sider>
                        <Layout>
                            <Content>
                                <Header>
                                    <>
                                    </>
                                </Header>
                                <hr />
                                <Header>
                                    <>
                                    </>
                                </Header>
                                <hr />
                                {/* <SignRenderNode data={asigns} /> */}
                                <div className="ex3">
                                    <SignRenderNode data={asigns} />
                                </div>

                            </Content>
                            <Footer>


                            </Footer>
                        </Layout>
                    </Layout>
                </>
            </Modal>
        </>
    );
}

export default Signs