# SPDX-License-Identifier: MIT
from .definition import parser, ResourceType  # noqa
from .core import CLI, CVAT_API_V2  # noqa
